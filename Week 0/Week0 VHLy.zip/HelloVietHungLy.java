public class HelloVietHungLy {
	public static void main(String[] args) {
		// gebe Name aus
		System.out.println("Hallo Tutorinnen und Tutoren! \nIch wurde von Viet Hung Lý programmiert.");
	}
}