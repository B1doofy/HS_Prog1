public class DogArt{
    public static void main(String[] args) {
    
	    System.out.println("   ______________________");
        System.out.println(" <  Mein Name ist Howl >");
        System.out.println("   ----------------------");
        System.out.println("/ \\__          /");
        System.out.println("(     @\\___    /");
        System.out.println(" /         O");
        System.out.println("/  (_____/ ");
        System.out.println("/_____/ U");
	}
}
